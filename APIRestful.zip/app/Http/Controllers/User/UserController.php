<?php

namespace App\Http\Controllers\User;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use App\User;
use App\Login;

class UserController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $users = User::all();
        return response()->json(['data' =>$users], 200);
        exit();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
      $rules =
      [
        'email' => 'required|email|unique:tblUsers',
        'name' => 'required',
        'namecompany' => 'required|min:6',
        'url' => 'required|min:6',
        'password' => 'required|min:6|confirmed',
        'typeUser' => 'required',
      ];

      $this->validate($request, $rules);
        $fields = $request->all();
        // $fields['password'] =  bcrypt($request->password);
        $fields['tokenUser'] =  User::generateToken();
        $fields['fkIdMaster'] =  $fields['typeUser'];

        $loginSesion = Login::class;

        return DB::transaction(function() use ($fields, $loginSesion)
        {
            $user = User::create($fields);
            $lastIdUser = $user->id;
            $dataLogin =
            [
              'name' => $fields['email'],
              'password' => $fields['password'],
              'fkIdUser' => $lastIdUser
            ];

            $login = $loginSesion::create($dataLogin);

            return response()->json(['data' => $user], 201);
        });
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $user = User::findOrFail($id);

        return response()->json(['data' => $user], 200);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
