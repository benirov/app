<!-- Compiled app javascript -->
<script src="<?php echo e(asset('/js/app.js')); ?>"></script>
